import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class PedidoDataService {
  constructor() {}
  private pedidoSource = new BehaviorSubject({ pedido: null, key: '' });
  pedidoAtual = this.pedidoSource.asObservable();

  obtemPedido(pedido: pedido, key: string) {
    this.pedidoSource.next({ pedido: pedido, key: key });
  }
}
