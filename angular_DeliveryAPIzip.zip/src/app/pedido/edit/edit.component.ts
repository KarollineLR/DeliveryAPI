import { Component, OnInit } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { pedido } from '../pedido';
import { pedidoService } from '../pedido.service';
import { pedidoDataService } from '../pedido-data.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css'],
})
export class EditComponent implements OnInit {
  pedido: pedido;
  key: string = '';

  constructor(
    private _pedidoService: pedidoService,
    private _pedidoDataService: pedidoDataService
  ) {}

  ngOnInit() {
    this.pedido = new pedido();
    this.pedidoDataService.pedidoAtual.subscribe((data) => {
      if (data.pedido && data.key) {
        this.pedido = new pedido();
        this.pedido.nome = data.pedido.nome;
        this.pedido.valor = data.pedido.valor;
        this.key = data.key;
      }
    });
  }

  onSubmit() {
    if (this.key) {
      this.pedidoService.update(this.pedido, this.key);
    } else {
      this.pedidoService.insert(this.pedido);
    }

    this.pedido = new pedido();
    this.key = null;
  }
}
