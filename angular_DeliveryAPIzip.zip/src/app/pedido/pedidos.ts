export class Pedidos {
  nome: string;
  valor: decimal;
}
