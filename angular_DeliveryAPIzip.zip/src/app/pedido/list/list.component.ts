import { Component, OnInit } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { pedidoService } from '../pedido.service';
import { Observable } from 'rxjs';
import { pedidoDataService } from '../pedido-data.service';
import { pedido } from '../pedido';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css'],
})
export class ListComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
  pedidos: Observable<any>;

  constructor(
    private pedidoService: pedidoService,
    private pedidoDataService: pedidoDataService
  ) {}

  ngOnInit() {
    this.pedidos = this.pedidoService.getAll();
  }

  delete(key: string) {
    this.pedidoService.delete(key);
  }

  edit(pedido: pedido, key: string) {
    this.pedidoDataService.mudapedido(pedido, key);
  }
}
