import { Pedidos } from './pedidos';

describe('Pedidos', () => {
  it('should create an instance', () => {
    expect(new Pedidos()).toBeTruthy();
  });
});
